/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NEGOCIO;

/**
 *
 * @author docente
 */
public class Carro {
    private String placa;
    private String tipoCarro;
    private Cliente myCliente;
    
    
/*constructor con parametros */
    public Carro(String placa, String tipoCarro, Cliente myCliente) {
        this.placa = placa;
        this.tipoCarro = tipoCarro;//automovil, camioneta, buseta, camion
        this.myCliente = myCliente;
    }
/* constructor  por default */
    public Carro() {
    }

   /* los metodos get y  set por cada atributo **/ 
    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getTipoCarro() {
        return tipoCarro;
    }

    public void setTipoCarro(String tipoCarro) {
        this.tipoCarro = tipoCarro;
    }

    public Cliente getMyCliente() {
        return myCliente;
    }

    public void setMyCliente(Cliente myCliente) {
        this.myCliente = myCliente;
    }

    @Override
    public String toString() {
        return "Carro{" + "placa=" + this.placa + ", tipoCarro=" + this.tipoCarro + 
               ", myCliente=" + this.myCliente + '}'; //PENDIENTE
    }
   
    
    
    
    
    
    
    
}
