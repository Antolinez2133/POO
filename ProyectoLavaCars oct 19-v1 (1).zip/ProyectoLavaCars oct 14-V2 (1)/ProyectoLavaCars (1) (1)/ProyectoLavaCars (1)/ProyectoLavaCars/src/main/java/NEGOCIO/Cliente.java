/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NEGOCIO;

/**
 *
 * @author docente
 */
public class Cliente extends Persona{
    private String fechaNac;
    private String tipoCliente; //persona, empresa
    
    
   public Cliente(String cedula,String nombre, String telefono,String fechaNac, String tipoC){
       super(cedula,nombre,telefono);
       this.fechaNac=fechaNac;
       this.tipoCliente=tipoC;
   } 
   
   public Cliente(String cedula,String nombre, String telefono){
       super(cedula,nombre,telefono);
       this.tipoCliente="persona";
   }

    public String getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public String getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(String tipoCliente) {
        this.tipoCliente = tipoCliente;
    }
   
    public String toString(){
        return super.toString()+ "Fecha Nacim (dd/mm/año):"+
                this.fechaNac+"\n"+"TipoCliente:"+ this.tipoCliente;
        
    }
   
   
   
    
    
}
