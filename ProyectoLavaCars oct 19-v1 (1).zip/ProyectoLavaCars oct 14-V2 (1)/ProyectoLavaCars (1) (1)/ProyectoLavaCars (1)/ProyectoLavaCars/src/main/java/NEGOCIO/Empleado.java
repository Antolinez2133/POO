/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NEGOCIO;

/**
 *
 * @author docente
 */
public class Empleado extends Persona {
    private int sueldoBase;
    private int propinas;
    
    public Empleado(String cedula,String nombre, String telefono,int sueldoBase){
        super(cedula,nombre,telefono);
        this.sueldoBase=sueldoBase;
    }

    public int getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(int sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    public int getPropinas() {
        return propinas;
    }

    public void setPropinas(int propinas) {
        this.propinas = propinas;
    }
    
    public String toString(){
        return super.toString()+"\n"+"Sueldo Basico: "+this.sueldoBase+
                         "\n"+"Propinas:"+this.propinas;
    }
    
    
    
}
