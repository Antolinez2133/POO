/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NEGOCIO;

/**
 *
 * @author docente
 */
public class Factura {
    private String numero;
    private OrdenServicio myOrden;
    private int totalPagar;

    public Factura(String numero, OrdenServicio myOrden) {
        this.numero = numero;
        this.myOrden = myOrden;
        this.calcularTotalPagar();
    }
 
    //calcular el total a pagar en la factura segun los servicios de la orden
    private void calcularTotalPagar(){
        
    }
    
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public OrdenServicio getMyOrden() {
        return myOrden;
    }

    public void setMyOrden(OrdenServicio myOrden) {
        this.myOrden = myOrden;
    }

    public int getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(int totalPagar) {
        this.totalPagar = totalPagar;
    }
    
    
    
    
    
}
