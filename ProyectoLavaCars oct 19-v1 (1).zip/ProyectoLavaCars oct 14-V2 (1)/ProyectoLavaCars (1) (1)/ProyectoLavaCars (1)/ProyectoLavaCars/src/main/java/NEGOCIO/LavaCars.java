/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NEGOCIO;

/**
 *
 * @author docente
 */
public class LavaCars {
    private Puesto myP1;
    private Puesto myP2;
    private Puesto myP3;
    private Puesto myP4;
    private Cliente myCliente1;
    private Cliente myCliente2;
    private OrdenServicio myOrd1;
    private OrdenServicio myOrd2;
    private Carro myCar1;
    private Carro myCar2;
    private Empleado myEmp1;
    private Empleado myEmp2;
    private Empleado myEmp3;
    
    /* constructor LavaCars**/
       
    public LavaCars(){
        //crea los puestos 
        this.crearPuestos();
        this.agregarEmpleado();
    }
    
    // metodo de la parte fisica de lavaCars
    private void crearPuestos(){
       this.myP1=new Puesto(1);
       this.myP2=new Puesto(2);
       this.myP3=new Puesto(3);
       this.myP4=new Puesto(4);
    }
    
    
     public String listarPuestosLibres(){
        String cad=""; 
        int p=0;
        
        p=this.myP1.verificarPuestoLibre();
        if(p!=0){
            cad=cad+Integer.toString(p)+"/";
        }
        p=this.myP2.verificarPuestoLibre();
        if(p!=0){
            cad=cad+Integer.toString(p)+"/";
        }
        p=this.myP3.verificarPuestoLibre();
        if(p!=0){
            cad=cad+Integer.toString(p)+"/";
        }
        p=this.myP4.verificarPuestoLibre();
        if(p!=0){
            cad=cad+Integer.toString(p)+"/";
        }
        return cad;
    }
    
    
    //metodo de tipo operación - Se desprende
    //del RF registrar Orden Servicio 
    
    public String validarCliente(String cedula){
        String cad="";
        Cliente myC=buscarCliente(cedula);
        if(myC!=null){
            cad=myC.getNombre()+"/"+myC.getTelefono();
        }
        return cad;
    }
    
    
    //metodo para enviar empleados libres 
    //concatenar la cedula-nombre del empleado
    public String listarEmpleadosLibres(String fecha){
        String cad="";
        if(this.myEmp1!=null&& verificarEmpleadoLibre(fecha,this.myEmp1)){
            cad=cad+this.myEmp1.getCedula()+"-"+this.myEmp1.getNombre()+"/";
        }
        if(this.myEmp2!=null&& verificarEmpleadoLibre(fecha,this.myEmp2)){
            cad=cad+this.myEmp2.getCedula()+"-"+this.myEmp2.getNombre()+"/";
        }
        if(this.myEmp3!=null&& verificarEmpleadoLibre(fecha,this.myEmp3)){
            cad=cad+this.myEmp3.getCedula()+"-"+this.myEmp3.getNombre()+"/";
        }
        
        return cad;
    }
    
    
    //metodo para buscar el empleado en cada orden de servicio
    
    private boolean verificarEmpleadoLibre(String fecha, Empleado emp){
        
        if(this.myOrd1!=null){
            if(this.myOrd1.isEstado()&&this.myOrd1.getFecha().equals(fecha)&&this.myOrd1.getMyEmpleado()==emp){
                return false;
            }
        }
        if(this.myOrd2!=null){
            if(this.myOrd2.isEstado()&&this.myOrd2.getFecha().equals(fecha)&&this.myOrd2.getMyEmpleado()==emp){
                return false;
            }
        }
       
        return true;
    }
    
   
    
    
    //METODO PRIVATE DE BUSCAR OBJETO CLIENTE
    private Cliente buscarCliente(String cedula){
        Cliente c=null;
        if(this.myCliente1!=null&&this.myCliente1.getCedula().equals(cedula)){
            c=myCliente1;
        }else if(this.myCliente2!=null&&this.myCliente2.getCedula().equals(cedula)){
             c=myCliente2;
        }
        return c;
        
    }
    
    
    
    
    private void agregarEmpleado(){
      // this.myEmp1=new Empleado("4545","luis carlos","312456789",120000);
        
    }
    
    //ENCABEZADOS DE LOS REQUERIMIENTOS FUNCIONALES
    /*listar los puestos con el estado "libre" o "ocupado", en caso de estar ocupado mostrar el numero de la placa **/
    public String consultarPuestos(){
        String cad="";
        if(this.myP1!=null){
            cad= "NUMERO PUESTO: "+this.myP1.getNumero()+"\t"+"ESTADO PUESTO: "+this.myP1.mostrarEstadoPuesto()+
                 "\n";
        }
        if(this.myP2!=null){
            cad= cad+"NUMERO PUESTO: "+this.myP2.getNumero()+"\t"+"ESTADO PUESTO: "+this.myP2.mostrarEstadoPuesto()+
                 "\n";
        }
        if(this.myP3!=null){
            cad= cad+"NUMERO PUESTO: "+this.myP3.getNumero()+"\t"+"ESTADO PUESTO: "+this.myP3.mostrarEstadoPuesto()+
                 "\n";
        }
        if(this.myP4!=null){
            cad= cad+"NUMERO PUESTO: "+this.myP4.getNumero()+"\t"+"ESTADO PUESTO: "+this.myP4.mostrarEstadoPuesto()+
                 "\n";
        }
        return cad;
        
    }
    // METODO QUE DEBE RETORNAR EL NUMERO DE LA ORDEN
    
    public int consultarNumeroOrdenServicio(){
        int numO=0;
        if(this.myOrd1==null){
            numO++;
        }else if(this.myOrd2==null){
            numO=this.myOrd1.getNumeroOrden()+1;
        }
        return numO;
      
    }
    //metodo para registrar un cliente
    private  void registrarCliente(String cedula,String nombre,String telef){
        if(this.myCliente1==null){
            this.myCliente1=new Cliente(cedula,nombre,telef);
        }else if(this.myCliente2==null){
            this.myCliente2=new Cliente(cedula,nombre,telef);
        }
    }
    
    //metodo para buscar un objeto carro
    private Carro buscarCarro(String placa){
        Carro c=null;
        if(this.myCar1!=null&&this.myCar1.getPlaca().equals(placa)){
            c=this.myCar1;
        }else if(this.myCar2!=null&&this.myCar2.getPlaca().equals(placa)){
            c=this.myCar2;
        }
       return c; 
    }
    //metodo para crear Carro
    private void registrarCarro(String placa,Cliente myCliente){
        
        if(this.myCar1==null){
            this.myCar1=new Carro(placa,"automovil",myCliente);
        }else if(this.myCar2==null){
            this.myCar2=new Carro(placa,"automovil",myCliente);
        }
    }
    
    private Empleado buscarEmpleado(String cedulaEmp){
        Empleado emp=null;
         if(this.myEmp1!=null&&this.myEmp1.getCedula().equals(cedulaEmp)){
             emp=this.myEmp1;
         } if(this.myEmp2!=null&&this.myEmp2.getCedula().equals(cedulaEmp)){
             emp=this.myEmp2;
         }  if(this.myEmp3!=null&&this.myEmp3.getCedula().equals(cedulaEmp)){
             emp=this.myEmp3;
         }
         return emp;
    }
    
    
    
   //registrar orden de servicio 
    public String registrarOrdenServicio(int numO,String fecha,String hora,
            String placa,String cedula,String nombre, String telef,
            String cedulaEmp,int numPuesto,boolean [] serv){
      String cad="";
        Cliente myCliente=this.buscarCliente(cedula);
        if(myCliente==null){
            this.registrarCliente(cedula, nombre, telef);
        }
        Carro myCarro=this.buscarCarro(placa);
        if(myCarro==null){
            this.registrarCarro(placa,myCliente);
        }
        Empleado myEmpleado=this.buscarEmpleado(cedulaEmp);
        if(this.myOrd1==null){
            this.myOrd1=new OrdenServicio(numO,myCarro,numPuesto,
              myEmpleado,fecha,hora,serv);
            cad="REGISTRO EXITOSO..."+
                "\nvalor a pagar sin descuentos:"+this.myOrd1.getTotalPagar();
        }else if(this.myOrd2==null){
            this.myOrd2=new OrdenServicio(numO,myCarro,numPuesto,
              myEmpleado,fecha,hora,serv);
             cad="REGISTRO EXITOSO..."+
                  "\nvalor a pagar sin descuentos:"+this.myOrd2.getTotalPagar();
        }else {
            cad="LO SENTIMOS NO PODEMOS ATENDER EL SERVICIO";
        }
           
        return cad;
     }
}