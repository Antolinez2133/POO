/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NEGOCIO;

/**
 *
 * @author docente
 */
public class OrdenServicio {
    private int numeroOrden;
    private Carro myCarro;
    private int numPuestoA;
    private Empleado myEmpleado;
    private String fecha;
    private String horaLLegada;
    private String horaSalida;
    private float totalPagar;
    private boolean [] servicios;
    private boolean estado;//true =si está abierta la orden..   false =si pasa a facturar

    public OrdenServicio() {
    }

       
    public OrdenServicio(int numeroOrden,Carro myCarro, int numP,Empleado myEmpleado, String fecha, String horaLLegada, boolean[] servicios) {
        this.numeroOrden=numeroOrden;
        this.numPuestoA=numP;
        this.myCarro = myCarro;
        this.myEmpleado = myEmpleado;
        this.fecha = fecha;
        this.horaLLegada = horaLLegada;
        this.servicios = servicios;
        this.estado=true;
    }
    
    private float calcularValorServicios(String tipo){
        float valorTotal=0.0F;
        if(tipo.equals("automovil")){
            if(this.servicios[0]==true){
                valorTotal=35000;
            }
            if(this.servicios[1]==true){
                valorTotal=valorTotal +65000;
            }
            if(this.servicios[2]==true){
                valorTotal=valorTotal+90000;
            }
        }else if(tipo.equals("camioneta")){
            if(this.servicios[0]==true){
                valorTotal=45000;
            }
            if(this.servicios[1]==true){
                valorTotal=valorTotal +80000;
            }
            if(this.servicios[2]==true){
                valorTotal=valorTotal+110000;
            }
        }else if(tipo.equals("buseta")){
            if(this.servicios[0]==true){
                valorTotal=75000;
            }
            if(this.servicios[1]==true){
                valorTotal=valorTotal +130000;
            }
            if(this.servicios[2]==true){
                valorTotal=valorTotal+180000;
            }
        }else if(tipo.equals("camion")){
            if(this.servicios[0]==true){
                valorTotal=120000;
            }
        }
      
        return valorTotal;
    }
    
    
    //metodo para calcular el total a pagar segun servicios
    public float calcularTotalPagar(){
        
        switch(this.myCarro.getTipoCarro()){
            case "automovil":
                this.totalPagar=this.calcularValorServicios("automovil");
                break;
            case "camioneta":
                this.totalPagar=this.calcularValorServicios("camioneta");
                break;
            case "buseta":
                this.totalPagar=this.calcularValorServicios("buseta");
                break;
           case "camion":
                this.totalPagar=this.calcularValorServicios("camion");
                break;
        }
      return this.getTotalPagar();
    }
    
    public int getNumeroOrden() {
        return numeroOrden;
        
    }

    public void setNumeroOrden(int numeroOrden) {
        this.numeroOrden = numeroOrden;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    
    
    public int getNumPuestoA() {
        return numPuestoA;
    }

    public void setNumPuestoA(int numPuestoA) {
        this.numPuestoA = numPuestoA;
    }

    
    
    public Carro getMyCarro() {
        return myCarro;
    }

    public void setMyCarro(Carro myCarro) {
        this.myCarro = myCarro;
    }

    public Empleado getMyEmpleado() {
        return myEmpleado;
    }

    public void setMyEmpleado(Empleado myEmpleado) {
        this.myEmpleado = myEmpleado;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getHoraLLegada() {
        return horaLLegada;
    }

    public void setHoraLLegada(String horaLLegada) {
        this.horaLLegada = horaLLegada;
    }

    public String getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(String horaSalida) {
        this.horaSalida = horaSalida;
    }

    public float getTotalPagar() {
        return totalPagar;
    }

    public void setTotalPagar(float totalPagar) {
        this.totalPagar = totalPagar;
    }

    public boolean[] getServicios() {
        return servicios;
    }

    public void setServicios(boolean[] servicios) {
        this.servicios = servicios;
    }
   
    //PENDIENTE*******
    private String mostrarServicios(){
        return null;
    }

    @Override
    public String toString() {
        return "OrdenServicio{" + "  Numero Orden: "+this.numeroOrden+"  Placa Carro=" + myCarro.getPlaca() + ", Nombre Empleado=" + myEmpleado.getNombre() + 
                ", Numero de puesto Asignado:"+this.getNumPuestoA()+
                ", fecha=" + fecha + ", horaLLegada=" + horaLLegada + ", horaSalida=" + horaSalida + ", totalPagar=" + totalPagar + 
                ", servicios=" + this.mostrarServicios() + '}';
    }
    
    
    
}
