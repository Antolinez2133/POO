/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package NEGOCIO;

/**
 *
 * @author docente
 */
public class Puesto {
    private int numero;
    private Carro myCarro;

    public Puesto(int numero) {
        this.numero = numero;
        this.myCarro=null;
    }

    public int verificarPuestoLibre(){
        int puesto=0;
        if(this.myCarro==null){
            puesto=this.numero;
        }
        return puesto;
    }
    
    
    public Puesto() {
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public Carro getMyCarro() {
        return myCarro;
    }

      
    public void setMyCarro(Carro myCarro) {
        this.myCarro = myCarro;
    }
    
    public String mostrarEstadoPuesto(){
        
        if(this.myCarro==null){
            return "Disponible";
        }
        return "Ocupado"+"\t"+"PLACA:"+this.myCarro.getPlaca();
     
    }

    @Override
    public String toString() {
        return "Puesto{" + "numero=" + numero + ", myCarro=" + myCarro + '}';
    }

    
    
    
    
    
    
}
